package com.gl.test.springbootAssignmentProject;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.test.springbootAssignmentProject.model.Ticket;
import com.gl.test.springbootAssignmentProject.model.TicketService;

@Controller
public class TicketController 
{
	@Autowired
	TicketService ticketService;
	
	@RequestMapping("/home")
	public String homepage(Model data) 
	{	
		List<Ticket> ticket=ticketService.getall();	
		data.addAttribute("ticket",ticket);	
		return "showticket";
	}
	
	@PostMapping("/addTicket")
	public String addTicket(@RequestParam int id,@RequestParam String TicketTitle,@RequestParam String TicketShortDescription,@RequestParam LocalDate TicketCreatedOn,@RequestParam String Content,Model data) 
	{
		Ticket ticket1=new Ticket(id,TicketTitle,TicketShortDescription,TicketCreatedOn,Content);
		ticketService.add(ticket1);
		List<Ticket> ticket=ticketService.getall();
		data.addAttribute("ticket",ticket);	
		return "showticket";
	}
	
	@RequestMapping("/newticket")
	public String newticket() 
	{
		return "home";
	}
	
	@GetMapping("/search")
	public String search(@RequestParam String TicketTitle,Model data) 
	{
		List<Ticket> search=ticketService.filterByName(TicketTitle);
			if(search.isEmpty() )
			{	
				return "noticket";
			}
			else
			{
				data.addAttribute("ticket",search);
				return "search";
			}
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam int id,Model data)
	{
		Ticket ticket2= new Ticket(id,"","",null, null);
		ticketService.delete(ticket2);
		List<Ticket> ticket=ticketService.getall();
		data.addAttribute("ticket",ticket);	
		return "showticket";
	}
	
	@GetMapping("/edit")
	public String edit(@RequestParam int id,Model data) 
	{
		Ticket ticket3=ticketService.findById(id);
		ticketService.update(ticket3);
		data.addAttribute("ticket",ticket3);	
		return "edit";
	}
	
	@GetMapping("/update")
	public String update(@RequestParam int id,@RequestParam String TicketTitle,@RequestParam String TicketShortDescription,@RequestParam LocalDate TicketCreatedOn,@RequestParam String Content,Model data) 
	{
		Ticket ticket4=new Ticket(id,TicketTitle,TicketShortDescription,TicketCreatedOn,Content);
		ticketService.add(ticket4);
		List<Ticket> ticket=ticketService.getall();
		data.addAttribute("ticket",ticket);
		return "showticket";
	}
	
	@RequestMapping("/view")
	public String view(Model data) 
	{
		List<Ticket> ticket=ticketService.getall();
		data.addAttribute("ticket",ticket);
		return "view";
	}
	
	@RequestMapping("/Back")
	public String back()
	{	
		return "showticket";
	}
}

