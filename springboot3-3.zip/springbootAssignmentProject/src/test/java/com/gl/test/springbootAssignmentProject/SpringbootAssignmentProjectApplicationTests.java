package com.gl.test.springbootAssignmentProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAssignmentProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
